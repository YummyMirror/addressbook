PHP Address Book
================

Read "_USER_GUIDE.pdf" for further informations about:
* Installations
* Upgrades
* User setup
* Smart Phone integration
* Export / Import
* Language support
* ... and much more

ENJOY !!


(c)AGPL by chatelao 2007-2012